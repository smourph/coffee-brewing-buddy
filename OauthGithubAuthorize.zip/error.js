const { constants } = require('./constants')

exports.generateErrorObject = (message, exception = null, response = null) => {
  return {
    statusCode: 400,
    body: JSON.stringify({
      error: message,
      exception,
      response
    }),
    headers: {
      ...constants.commonResponseHeaders,
      ...constants.corsHeaders
    }
  }
}

