/**
 * Based on https://github.com/Dasmicrobot/github-activity-server/blob/master/api/githubAuthorization.js
 * https://developer.github.com/apps/building-oauth-apps/authorizing-oauth-apps/
 */

const { generateErrorObject } = require('./error')
const baseUrl = 'https://github.com'
const authorizePath = '/login/oauth/authorize'
const defaultScope = 'read:user,gist'
const allowSignup = 'true'

function extractApiConsumer (event) {
  const queryStringParameters = event.queryStringParameters || {}
  return queryStringParameters.api
}

function extractScope (event) {
  const queryStringParameters = event.queryStringParameters || {}
  return queryStringParameters.scope
}

exports.handler = async (event, context) => {
  
  console.log('event', event);
  console.log('context', event);

  const apiConsumer = extractApiConsumer(event);

  if (!apiConsumer) {
    return generateErrorObject('Did not get expected query string named [api]')
  }

  const apiClientIdName = apiConsumer.toUpperCase() + '_CLIENT_ID';

  if (!process.env[apiClientIdName]) {
    return generateErrorObject(apiClientIdName + ' is not set in environment')
  }

  const scope = extractScope(event) ? extractScope(event) : defaultScope

  const authorizationUrl = `${baseUrl}${authorizePath}?client_id=${process.env[apiClientIdName]}&scope=${scope}&allow_signup=${allowSignup}`

  return {
    statusCode: 302,
    headers: {
      Location: authorizationUrl
    },
    body: null
  }
}

