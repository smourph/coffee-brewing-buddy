/**
 * Based on https://github.com/Dasmicrobot/github-activity-server/blob/master/api/githubAuthorizationCallback.js
 * https://developer.github.com/apps/building-oauth-apps/authorizing-oauth-apps/
 */

const { constants } = require('./constants')
const { generateErrorObject } = require('./error')
const { asyncHttpsRequest } = require('./request')
const { URL } = require('url')

function extractApiConsumer (event) {
  const queryStringParameters = event.queryStringParameters || {}
  return queryStringParameters.api
}

function extractCode (event) {
  const queryStringParameters = event.queryStringParameters || {}
  return queryStringParameters.code
}

async function exchangeCodeForToken (clientId, clientSecret, code) {
  const api = new URL('/login/oauth/access_token', 'https://github.com')
  api.searchParams.set('client_id', clientId)
  api.searchParams.set('client_secret', clientSecret)
  api.searchParams.set('code', code)

  return asyncHttpsRequest(api, 'POST')
}

exports.handler = async (event, context) => {
  
  console.log('event', event);
  console.log('context', context);

  const apiConsumer = extractApiConsumer(event);

  if (!apiConsumer) {
    return generateErrorObject('Did not get expected query string named [api]')
  }

  const apiClientIdName = apiConsumer.toUpperCase() + '_CLIENT_ID';

  if (!process.env[apiClientIdName]) {
    return generateErrorObject(apiClientIdName + ' is not set in environment')
  }

  const apiClientSecretName = apiConsumer.toUpperCase() + '_CLIENT_SECRET';

  if (!process.env[apiClientSecretName]) {
    return generateErrorObject(apiClientSecretName + ' is not set in environment')
  }

  const apiCallbackUrlName = apiConsumer.toUpperCase() + '_CALLBACK_URL';

  if (!process.env[apiCallbackUrlName]) {
    return generateErrorObject(apiCallbackUrlName + ' is not set in environment')
  }

  const code = extractCode(event)

  if (!code) {
    return generateErrorObject('Did not get expected query string named [code]')
  }

  let response
  try {
    response = await exchangeCodeForToken(process.env[apiClientIdName], process.env[apiClientSecretName], code)
  } catch (e) {
    console.error('response', response)
    return generateErrorObject('Failed to exchange code for access_token', e, response)
  }

  if (!response || !response.data.access_token) {
    console.error('response', response)
    return generateErrorObject('did not receive expected [access_token]')
  }

  return {
    statusCode: 302,
    headers: {
      Location: `${process.env[apiCallbackUrlName]}?${constants.authRedirectTokenParam}=${response.data.access_token}`
    },
    body: null
  }
}

